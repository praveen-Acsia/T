#include "track.h"
#include "mplayer.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
// #include<pthread.h>





int main(){
    
    // TRACK_SIZE++; //check later why this is needed. is it because you need to give null a space?
    
    //creating music track 
    struct Track** mtrack = (struct Track**) malloc(TRACK_SIZE * sizeof(struct Track*));
    for(int i =0;i<TRACK_SIZE;i++){
        mtrack[i] = (struct Track*) malloc((size_t)sizeof(struct Track*));
    }
    
    // track 0 
    setTrackId(mtrack[0],0);
    char* name="music-00";
    setTrackName(mtrack[0],name);
    setDuration(mtrack[0],3);

    // track 1 
    setTrackId(mtrack[1],1);
    name="music-01";
    setTrackName(mtrack[1],name);
    setDuration(mtrack[1],2);

    // track 2
    setTrackId(mtrack[2],2);
    name="music-02";
    setTrackName(mtrack[2],name);
    setDuration(mtrack[2],3);

    // track 3
    setTrackId(mtrack[3],3);
    name="music-03";
    setTrackName(mtrack[3],name);
    setDuration(mtrack[3],2);

    //saving duration details to play songs where they stoped.
    // int durationArr[TRACK_SIZE + 1];  //commented since songs are played from start in next and previos funtions.
    // for(int i =0;i<TRACK_SIZE;i++)
        // durationArr[i] = getDuration(mtrack[i]);

    //initializing currentMusic to the first song in the track list.
    
    struct currentMusic currMusic;
    currMusic.trackId = 0;
    currMusic.timeRemaining = mtrack[currMusic.trackId]->duration;

    int choice= -1;
    int* userInput = &choice;
    bool run = true;
    int playingMId = 0;

    // pthread_t scanThread;
    // pthread_create(&scanThread,NULL,usrInput,userInput);
    printf("user input : \n");
    scanf("%d",userInput);

    while(run){
        //printf("play(p)  pause(p)  next(j)  previous(l)  quit(q)");
        if(*userInput != -1)
        {
            switch(choice){

                case __PLAY:
                    Mplay(mtrack, &currMusic, userInput);
                    break; 

                case __PAUSE:
                    Mpause(mtrack, &currMusic, userInput);
                    break;

                case __NEXT:
                    Mnext(mtrack, &currMusic, userInput);
                    break;

                case __PREVIOUS:
                    Mprevious(mtrack,&currMusic,userInput);
                    break;

                case __QUIT:
                    free(mtrack);
                    exit(0);

                default:
                    printf("enter a valid input.");
                    break;
            }
        }
    }

    
}