#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include<unistd.h>



void *second(void *a) {
  // pthread_mutex_t mutex;
  // pthread_mutex_init(&mutex, NULL);

  while (1) {
    // Update variable 'a' and acquire lock
    // pthread_mutex_lock(&mutex);
    // a++;
    scanf("%d",(int*)a);
    printf("%d thread",*(int*)a);
    // Unlock for main thread to access 'a'
    // pthread_mutex_unlock(&mutex);

    // Sleep for one second
    sleep(1);
  }
  return NULL;
}

int main() {
  // Initialize the mutex
  // pthread_mutex_t mmutex;
  // pthread_mutex_init(&mmutex, NULL);
  int a =-1;
  // Create a thread to handle the second function
  pthread_t thread;
  pthread_create(&thread, NULL, second,&a);

  // Loop to continuously print 'a'
  while (1) {
    // Acquire lock to read 'a' safely
    // pthread_mutex_lock(&mutex);
    // printf("Variable a: %c\n", *b);
    // printf("inc %d",e++);
    // Release lock for 'second' to update 'a'
    if(a != -1){
      switch(a){
        case 1:
          while(a==1){
            
            sleep(1);
            // pthread_mutex_lock(&mmutex);
            // char cond = *b;
            printf("case 1 %d\n",a);
            // pthread_mutex_unlock(&mmutex);
            // if(cond!='a')
            //   break;
          }
          printf("a exit\n");
          break;
        case 2:
          while(a==2){
            printf("case b  %d\n",a);
            sleep(1);
          }
        break;
      }
      // pthread_mutex_unlock(&mutex);

      // Sleep for some time to avoid excessive printing
      sleep(0.5);
    }
  }

  // Join the thread (optional if you want to terminate the program)
  // pthread_join(thread, NULL);

  // Destroy the mutex
  // pthread_mutex_destroy(&mutex);

  return 0;
}
