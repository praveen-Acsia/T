#include<stdio.h>
#include<unistd.h>

void Mverbous(int timeElapsed, int duration){

    int elapsedHour = timeElapsed / 3600;
    int elapsedMinute = (timeElapsed % 3600) / 60;
    int elapsedSecond = (timeElapsed % 3600) % 60;
    int durationHour = duration / 3600;
    int durationMinute = (duration % 3600) / 60;
    int durationSecond = (duration % 3600) % 60;
    // system("cls");
    // printf("\x1b[1F");
    // printf("\x1b[2K");
    printf("\r%.2d:%.2d:%.2d / %.2d:%.2d:%.2d",elapsedHour, elapsedMinute, elapsedSecond, durationHour, durationMinute, durationSecond);
}


int main(){
    int time =5;
    int rou=6;
    while(time<=50){
        
        // printf("%d\n",-time % -(rou));
        time--;
        time = (time -1 +rou) % rou;
        // Mverbous(time,230);
        printf("%d\n",time);
        sleep(1);
        // printf("\rtime is %d",time++);
    }
    
}