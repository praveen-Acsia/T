#ifndef MPLAYER_H
#define MPLAYER_H

#include<unistd.h>
#include<stdbool.h>
#include "track.h"

#define __PLAY 1
#define __PAUSE 2
#define __NEXT 3
#define __PREVIOUS 4
#define __QUIT 5

bool IFPLAY;  //may need to change the position of decleration later.
struct currentMusic
{
    int trackId;
    int timeRemaining;
};


void Mverbous(struct Track**,struct currentMusic*, int , int);

void Mplay(struct Track**,struct currentMusic*, int*);

void Mpause(struct Track**, struct currentMusic*, int*);

void Mnext(struct Track** , struct currentMusic*, int* );

void Mprevious(struct Track**, struct currentMusic*, int*);

void usrInput(void*);

void pth(void* );

// void* usrInput(void*);


#endif