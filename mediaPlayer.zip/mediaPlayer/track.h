#ifndef TRACK_H
#define TRACK_H
#include<stdio.h>

int TRACK_SIZE;

struct Track{
        int trackId;
        char *trackName;
        int duration;
};

void setTrackId(struct Track* t,int id);

void setTrackName(struct Track* t,char* name);

void setDuration(struct Track* t,int dur);

int getTrackId(struct Track* t);

char* getTrackName(struct Track* t);

int getDuration(struct Track* t);

#endif