#include<string.h>
#include<stdio.h>
#include"track.h"

int TRACK_SIZE = 5;

void setTrackId(struct Track * t,int id){
    //to set trackid.
    t->trackId=id;
}
void setTrackName(struct Track * t,char* name){
    //to set track name.
    t->trackName = name;
}
void setDuration(struct Track * t,int dur){
    // to set duration.
    t->duration=dur;
}
int getTrackId(struct Track* t){
    // to get track id.
    return t->trackId;
}
char* getTrackName(struct Track * t){
    // to get track name.
    return t->trackName;
}
int getDuration(struct Track * t){
    // to get duration
    return t->duration;
}
