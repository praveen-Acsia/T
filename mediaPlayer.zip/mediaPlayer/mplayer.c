#include "mplayer.h"


void Mplay(struct Track** mtrack, struct currentMusic* currMusic, int*  userInput){

    IFPLAY = true;

    // printf("mplay started.");

    //saving current playing music details.
        // currMusic->trackId = playingMId;
        // currMusic->timeRemaining = mtrack[playingMId]->duration;
            //might not need here (initialised in main.c to the first music).

    while(*userInput == __PLAY){
        
        sleep(1); //simulate clock.
        
        //calculating remaining time and printing it.
        currMusic->timeRemaining--;
        int timeElapsed = mtrack[currMusic->trackId]->duration - currMusic->timeRemaining;
        Mverbous(mtrack, currMusic, timeElapsed, mtrack[currMusic->trackId]->duration);

        //automatic next song incase the song is finished.
        if(currMusic->timeRemaining == 0){
            // Mnext(mtrack,currMusic,userInput);
            *userInput = __NEXT;
            break;
        }
    }   
}

void Mpause(struct Track** mtrack, struct currentMusic* currMusic, int* userInput){

    IFPLAY = false;
    //print the total and elapsed time. 
    int timeElapsed = mtrack[currMusic->trackId]->duration - currMusic->timeRemaining;
    Mverbous(mtrack, currMusic, timeElapsed, mtrack[currMusic->trackId]->duration);
    while(*userInput == __PAUSE){
        ;
    }
}

void Mnext(struct Track** mtrack, struct currentMusic* currMusic, int* userInput){

    currMusic->trackId = (currMusic->trackId + 1) % (TRACK_SIZE - 1); 
    currMusic->timeRemaining = mtrack[currMusic->trackId]->duration;

    if(IFPLAY)
        *userInput = __PLAY;
    else
        *userInput = __PAUSE;
}

void Mprevious(struct Track** mtrack, struct currentMusic* currMusic, int* userInput){

    currMusic->trackId --; 
    if(currMusic->trackId < 0) currMusic->trackId = TRACK_SIZE - 2;
    currMusic->timeRemaining = mtrack[currMusic->trackId]->duration;

    if(IFPLAY)
        *userInput = __PLAY;
    else
        *userInput = __PAUSE;
}

void usrInput(void* userInput){
    //to take input from user.Will run parallel in a thread.
    while(1){
        printf("enter user input :\n"); //change it to appropriate words.
        scanf("%d",(int*)userInput);
    }
}

void Mverbous(struct Track** mtrack, struct currentMusic* currMusic, int timeElapsed, int duration){

    //print the elapsed and total time (HH:MM:SS / HH:MM:SS).
    int elapsedHour = timeElapsed / 3600;
    int elapsedMinute = (timeElapsed % 3600) / 60;
    int elapsedSecond = (timeElapsed % 3600) % 60;
    int durationHour = duration / 3600;
    int durationMinute = (duration % 3600) / 60;
    int durationSecond = (duration % 3600) % 60;

    printf("\rnow playing >>> %s <<<  %.2d:%.2d:%.2d / %.2d:%.2d:%.2d",mtrack[currMusic->trackId]->trackName, elapsedHour, elapsedMinute, elapsedSecond, durationHour, durationMinute, durationSecond);
}

//function to test, cleat it later.
void pth(void* arg)
{

    while(*(int*)arg==__PLAY){

        printf("thread %d\n",*(int*)arg);
        sleep(1);
    }
    printf("pht.h exit\n");
}




